#' @title Estimate the Asymmetric Peer Effects Model
#'
#' @param formula An object of class \link[stats]{formula}: a symbolic description 
#'   of the model. It should be specified as \code{y ~ x1 + x2 + ...}, where 
#'   \code{y} is the outcome variable and \code{x1}, \code{x2}, ... are control 
#'   variables, which may include contextual variables such as peer averages.
#'
#' @param excluded.instruments A \link[stats]{formula} specifying the excluded 
#'   instruments. It should be written as \code{~ z1 + z2 + ...}, where 
#'   \code{z1}, \code{z2}, ... are the excluded instruments for the two endogenous 
#'   variables in the asymmetric model: the average peers' outcomes and the average 
#'   difference in outcomes between an agent and her higher-performing peers. If 
#'   omitted, default instruments are generated using \link{gen.instrument}.
#'
#' @param common.gamma A character vector indicating the control variables assumed 
#'   to have the same marginal effect on marginal utility for isolated and 
#'   non-isolated agents. If omitted, all control variables are included. A value 
#'   of \code{NULL} or \code{character(0)} indicates that none are included.
#'
#' @param Glist The adjacency matrix or list of adjacency matrices. For networks 
#'   consisting of multiple subnets (e.g., schools), \code{Glist} must be a list, 
#'   where the \code{s}-th element is an \eqn{n_s x n_s} adjacency matrix and 
#'   \eqn{n_s} is the number of nodes in subnet \code{s}.
#'
#' @param data An optional data frame, list, or environment (or an object that can 
#'   be coerced to a data frame via \link[base]{as.data.frame}) containing the 
#'   variables in the model. If a variable is not found in \code{data}, it is 
#'   retrieved from \code{environment(formula)}, typically the environment from 
#'   which \code{asypeer.estim} is called.
#'
#' @param weight A character string specifying the weighting matrix used in GMM 
#'   estimation. Available options are \code{"identity"} for GMM with the identity 
#'   matrix, \code{"IV"} for the standard instrumental-variable GMM estimator, and 
#'   \code{"optimal"} for GMM with the optimal weighting matrix.
#'
#' @param nboot The number of bootstrap replications when \code{HAC = "cluster"}.
#'
#' @param tol A numeric tolerance used in QR factorization to detect collinear 
#'   columns in the matrices of explanatory variables and instruments, ensuring a 
#'   full-rank matrix (see \link[base]{qr}).
#'
#' @param HAC A character string specifying the correlation structure of the 
#'   idiosyncratic errors used for covariance estimation. Options are 
#'   \code{"iid"} for independent errors; \code{"group iid"} for independence within 
#'   groups of isolated and non-isolated agents; \code{"hetero"} for 
#'   heteroskedastic but non-autocorrelated errors; \code{"cluster"} for 
#'   heteroskedastic errors with within-subnetwork correlation; and 
#'   \code{"cboot"} for the pair-bootstrap version of \code{"cluster"}.
#'
#' @param fixed.effects A logical value indicating whether subnetwork fixed effects 
#'   are included in the model.
#'
#' @param nthread The number of CPU cores (threads) used for parallel computation.
#'
#' @param drop A logical vector of the same length as the sample, indicating which 
#'   observations should be dropped. This can be used, for example, to remove false 
#'   isolates or to estimate the model only for non-isolated agents. These 
#'   observations cannot be removed from the network structure because they may 
#'   remain connected to other agents.
#'
#' @param spillover A logical value indicating whether the model includes an 
#'   additional spillover component alongside the asymmetric conformity effect.
#'
#' @param asymmetry A logical value indicating whether preferences for conformity 
#'   are asymmetric.
#'
#' @param tol.optim A numeric tolerance used in \code{\link[stats]{optimize}}. The objective 
#'   function is concentrated in a function of \eqn{\beta_l} or \eqn{\beta} alone, 
#'   which is optimized using \link[stats]{optimize}.
#'
#' @param ... Further arguments passed to or from other methods.
#' 
#' @param gen.inst.arg A list of arguments for the \code{\link{gen.instrument}}
#'   function, used when instruments are to be generated. These arguments exclude 
#'   \code{formula}, \code{Glist}, \code{data}, \code{asymmetry}, 
#'   \code{fold.nthread}, \code{drop}, and \code{tol}, which are taken directly 
#'   from the \code{asypeer.estim} function.
#' 
#' @return A list containing:
#'     \item{model.info}{A list with information about the model, such as the number of subnets, number of observations, and other key details.}
#'     \item{gmm}{A list of GMM estimation results, including parameter estimates, the covariance matrix, and related statistics.}
#'     \item{data}{A list including the original data used to estimate the model, as well as the endogenous variables and their instruments.}
#' 
#' @description
#' `asypeer.estim` estimates the asymmetric peer effects model. The instruments are generated automatically following the procedure described 
#'   in the paper and implemented in \link{gen.instruments}. The user can also supply her own instruments.
#' @examples
#' if (requireNamespace("PartialNetwork", quietly = TRUE)) {
#' library(PartialNetwork)
#' ngr  <- 50  # Number of subnets
#' nvec <- rep(30, ngr)  # Size of subnets
#' n    <- sum(nvec)
#' 
#'### Simulating Data
#' ## Network matrix
#' G   <- lapply(1:ngr, function(z) {
#'  Gz <- matrix(rbinom(nvec[z]^2, 1, 0.3), nvec[z], nvec[z])
#'  diag(Gz) <- 0
#'  # Adding isolated nodes (important for the structural model)
#'  niso <- sample(0:nvec[z], 1, prob = ((nvec[z] + 1):1)^5 / sum(((nvec[z] + 1):1)^5))
#'  if (niso > 0) {
#'    Gz[sample(1:nvec[z], niso), ] <- 0
#'  }
#'  Gz
#' })
#' 
#' Gnorm   <- norm.network(G)
#' X       <- cbind(rnorm(n, 0, 2), rpois(n, 2))
#' GX      <- peer.avg(Gnorm, X)
#' delta   <- 0.25
#' beta    <- c(0.3, 0.6)
#' gamma   <- c(4, 1, -0.7, 0, -0.5) 
#' eps     <- rnorm(n, 0, 0.5) 
#' 
#' ## Generating `y`
#' y <- asypeer.sim(formula = ~ X + GX, Glist = Gnorm, delta = delta, beta = beta, 
#'                 gamma = gamma, epsilon = eps)
#' y <- y$y
#' 
#' ### Estimating the asymmetric peer effects model
#' est <- asypeer.estim(formula=y ~ X + GX, Glist = Gnorm, spillover = TRUE)
#' summary(est, diagnostic = TRUE)
#' }                  
#' @export
#' @importFrom stats pchisq
#' @importFrom stats optimize
asypeer.estim <- function(formula,
                          excluded.instruments,
                          Glist,
                          data,
                          common.gamma,
                          spillover     = FALSE,
                          asymmetry     = TRUE,
                          weight        = "IV",
                          HAC           = "group-iid",
                          nboot         = 500,
                          fixed.effects = FALSE,
                          tol           = 1e-10,
                          nthread       = 1,
                          drop          = NULL,
                          tol.optim     = .Machine$double.eps^0.25,
                          gen.inst.arg  = list(),
                          ...){
  ## Thread
  tp        <- fnthreads(nthread = nthread)
  if ((tp == 1) & (nthread != 1)) {
    warning("OpenMP is not available. Sequential processing is used.")
    nthread <- tp
  }
  
  ## Instrument
  Z        <- NULL
  detInst  <- list()
  zname    <- NULL
  if (missing(excluded.instruments)) {
    if (missing(data)) {
      data <- env(formula)
    }
    excluded.instruments <- NULL
    ARG    <-  c(list(formula = formula, Glist = Glist, data = data, 
                    asymmetry = asymmetry, fold.nthread = nthread, drop = drop, 
                    tol = tol, ...), gen.inst.arg) 
    Z      <- do.call(gen.inst, ARG)
    detInst$estimator <- Z$model.info$estimator
    detInst$power     <- Z$model.info$power
    detInst$full.pred <- Z$model.info$full
    Z                 <- Z$instruments
    zname             <- colnames(Z)
  }  else {
    if(length(excluded.instruments) != 2) stop("The `excluded.instruments` argument must be in the format ~ z1 + z2 + ...")
    if (missing(data)) {
      data      <- env(formula)
    }
    f.t.data    <- formula2data(formula = excluded.instruments, 
                                data = data, fixed.effects = FALSE, 
                                simulations = TRUE)
    Z           <- f.t.data$X
    zname       <- f.t.data$xname
  } 
  
  ## Network
  if (!is.list(Glist)) {
    if (is.matrix(Glist)) {
      Glist  <- list(Glist)
    } else {
      stop("Glist is neither a matrix nor a list")
    }
  }
  Glist      <- fGnormalise(Glist, nthread)
  
  ## HAC
  boot    <- FALSE
  HACn    <- NULL
  if (tolower(HAC) %in% c("iid","i.i.d")) {
    HAC   <- "iid"
    HACn  <- 0
  } else if (tolower(HAC) %in% c("group-iid", "g-iid", "group iid", "giid", "groupiid")) {
    HAC   <- "group-iid"
    HACn  <- 1
  } else if (tolower(HAC) %in% c("hetero","het","heter","heteroskedasticity","heteroscedasticity")) {
    HAC   <- "hetero"
    HACn  <- 2
  } else if (tolower(HAC) %in% c("cluster", "clustered","clus")) {
    HAC   <- "cluster"
    HACn  <- 3
  } else if (tolower(HAC) %in% c("cboot", "boot","bootstrap")) {
    HAC   <- "cluster (bootstrap)"
    HACn  <- 3
    boot  <- TRUE
  } else {
    stop("This HAC option is not available.")
  }
  if (HACn == 2 & fixed.effects > 0) {
    HAC   <- "cluster"
    HACn  <- 3
  }
  
  ## Weight
  if (tolower(weight) %in% c("i","identity")) {
    weight   <- "I"
  } else if (tolower(weight) %in% c("iv")) {
    weight   <- "IV"
  } else if (tolower(weight) %in% c("opti", "optimal","optim")) {
    weight   <- "optimal"
  } else {
    stop("This weighting option is not available.")
  }
  
  ## sizes
  dg       <- fnetwork(Glist = Glist)
  S        <- dg$S
  ldg      <- dg$ldg
  SIso     <- dg$SIs
  SnIso    <- dg$SnIs
  nvec     <- dg$nvec
  n        <- dg$n
  cumsn    <- dg$cumsn
  idpeer   <- dg$idpeer
  Iso      <- dg$Is
  lIso     <- dg$lIs
  nIso     <- dg$nIs
  lnIso    <- dg$lnIs
  n_iso    <- length(Iso)
  n_niso   <- n - n_iso
  dg       <- dg$dg
  if (!all(dg %in% c(0, 1))) {
    stop("G is not row-normalized.")
  }
  
  ## Formula to data
  formula  <- as.formula(formula)
  f.t.data <- formula2data(formula = formula, data = data, fixed.effects = fixed.effects,
                           simulations = FALSE)
  
  # X, exogenous variables
  X      <- f.t.data$X
  xname  <- f.t.data$xname
  Kx     <- length(xname)
  
  # outcome
  y      <- f.t.data$y
  yname  <- f.t.data$yname
  
  # endogenous variables
  endo   <- highlowstat1(X = as.matrix(y), G = Glist, cumsn = cumsn, nvec = nvec, 
                         ngroup = S, nthread = nthread)
  enname <- NULL
  if(asymmetry){
    endo   <- cbind(yb = endo$Xbar, ycheck = endo$Xbh - endo$gh * y)
    enname <- paste0(yname, c("_bar", "_check"))
  } else {
    endo   <- endo$Xbar
    enname <- paste0(yname, "_bar")
  }
  
  #drop
  if (!is.null(drop)) {
    dg       <- fdrop(drop = drop, ldg = ldg, S = S, nvec = nvec, y = y, 
                      X = X, Z = Z, endo = endo)
    S        <- dg$S
    SIso     <- dg$SIs
    SnIso    <- dg$SnIs
    nvec     <- dg$nvec
    n        <- dg$n
    cumsn    <- c(0, cumsum(nvec))
    Iso      <- dg$Is
    lIso     <- dg$lIs
    nIso     <- dg$nIs
    lnIso    <- dg$lnIs
    n_iso    <- length(Iso)
    n_niso   <- n - n_iso
    y        <- dg$y
    X        <- dg$X
    Z        <- dg$Z
    endo     <- dg$endo
    dg       <- dg$dg
  }
  invisible(gc())
  if (spillover && SnIso == 0) {
    stop("At least one subnet containing isolated nodes is required to estimate spillover effects.")
  }
  if (SnIso < 2) {
    stop("At least two subnets containing non-isolated nodes are required.")
  }
  
  # Demean
  if (fixed.effects) {
    y      <- c(Demean_separate(X = as.matrix(y), cumsn = cumsn, lIso = lIso, 
                                lnIso = lnIso, nthread = nthread))
    endo   <- Demean_separate(X = endo, cumsn = cumsn, lIso = lIso, 
                              lnIso = lnIso, nthread = nthread)
    X      <- Demean_separate(X = X, cumsn = cumsn, lIso = lIso, lnIso = lnIso, 
                              nthread = nthread)
    Z      <- Demean_separate(X = Z, cumsn = cumsn, lIso = lIso, lnIso = lnIso, 
                              nthread = nthread)
  }
  
  # Name endo
  colnames(endo) <- enname
  
  # X variables 
  colnames(X) <- xname
  X_iso       <- X * (1 - dg)
  X_niso      <- X * dg
  
  # common.gamma 
  if(missing(common.gamma)) {
    common.gamma <- xname
  }
  if(!all(common.gamma %in% xname)){
    stop("At least one variable name in `common.gamma` is not written correctly.")
  }
  
  cgamma    <- common.gamma
  ncgamma   <- setdiff(xname, cgamma)
  cgamma    <- which(xname %in% cgamma) - 1
  ncgamma   <- which(xname %in% ncgamma) - 1
  
  ## degree of freedom
  dfiso    <- NULL
  dfniso   <- NULL
  if (fixed.effects) {
    Kxiso  <- length(ncgamma)
    dfiso  <- n_iso - SIso - Kxiso
    dfniso <- n_niso - SnIso - asymmetry -1  - spillover - Kx + Kxiso
  } else {
    Kxiso  <- length(ncgamma)
    dfiso  <- n_iso - Kxiso
    dfniso <- n_niso - 1 - asymmetry - spillover - Kx + Kxiso
  }
  if ((dfiso <= 0) && HACn == 1) {
    HAC    <- "iid"
    HACn   <- 0
  }
  if (spillover && (dfiso <= 0)) {
    stop("Insufficient number of observations for isolated nodes.")
  }
  if (dfniso <= 0) {
    stop("Insufficient number of observations for non-isolated nodes.")
  }
  if ((length(cgamma) == 0) && spillover) {
    stop("`common.gamma` is needed to estimate spillover effects.")
  }
  
  ## [endo, X_iso, X_niso] should be full rank
  if (length(fcheckrank(X = cbind(endo, X_iso, X_niso), tol = tol)) < (Kx + length(ncgamma) + 1L + asymmetry + spillover)) {
    stop("The design matrix is not full rank.")
  }
  
  # Instruments
  Z           <- cbind(X_iso, X_niso, Z)
  zname       <- c(paste0("iso_", xname), paste0("niso_", xname), zname)
  colnames(Z) <- zname
  ## Remove unecessary instruments
  keepZ <- fcheckrank(X = Z, tol = tol) + 1
  Z     <- Z[, keepZ, drop = FALSE]
  zname <- zname[keepZ]  
  
  ## Check the number of instruments
  Kz     <- ncol(Z)
  if (Kz < (Kx + 1L + asymmetry + spillover)) {
    stop("Insufficient number of instruments: the model is not identified.")
  }
  if ((HACn == 3) & (Kz >= S)) {
    stop("Errors cannot be clustered because the number of instruments is larger than the number of subnets.")
  }
  
  ## Weight
  if (weight == "I"){
    W    <- diag(nrow = ncol(Z))
  } else if(weight %in% c("IV", "optimal")){ 
    W    <- solve(crossprod(Z) / n)
  }
  
  ## Estimation
  ### Matrix V
  V      <- fV(endo = endo, X = X, Iso = Iso, nIso = nIso, nc_gamma = ncgamma, 
               spillover = spillover)
  
  ### First step GMM
  opt    <- NULL
  if (spillover) {
    opt  <- optimize(f = fAsyobj, lower = -0.5, upper = 100, tol = tol.optim,
                     Z = Z, y = y, V = V, W = W, nIso = nIso)
    opt  <- c(opt, fGmmEstim(betal = opt$minimum, Z = Z, y = y, V = V, W = W, 
                             nIso = nIso))
  } else {
    opt  <- optimize(f = fAsyobj_nospill, lower = -0.5, upper = 100, tol = tol.optim,
                     Z = Z, y = y, Gy = endo[,1], V = V, W = W, nIso = nIso)
    opt  <- c(opt, fGmmEstim_nospill(betal = opt$minimum, Z = Z, y = y, Gy = endo[,1], 
                                     V = V, W = W, nIso = nIso))
  }
  
  ### Optimal weighting matrix if necessary
  if ((HACn != 0) & (weight == "optimal")) {
    W <- fAsyWopt(theta = opt$theta, Z = Z, eta = opt$eta, cumsn = cumsn, 
                  Iso = Iso, nIso = nIso, dfiso = dfiso, dfniso = dfniso, 
                  HAC = HACn, S = S)
    if (spillover) {
      opt  <- optimize(f = fAsyobj, lower = -0.5, upper = 100, tol = tol.optim,
                       Z = Z, y = y, V = V, W = W, nIso = nIso)
      opt  <- c(opt, fGmmEstim(betal = opt$minimum, Z = Z, y = y, V = V, W = W, 
                               nIso = nIso))
    } else {
      opt  <- optimize(f = fAsyobj_nospill, lower = -0.5, upper = 100, tol = tol.optim,
                       Z = Z, y = y, Gy = endo[,1], V = V, W = W, nIso = nIso)
      opt  <- c(opt, fGmmEstim_nospill(betal = opt$minimum, Z = Z, y = y, Gy = endo[,1], 
                                       V = V, W = W, nIso = nIso))
    }
  }
  
  ### Covariance
  Cov        <- NULL
  seed       <- as.integer(runif(1, 0, 1e9))
  if (boot) {
    outbt    <- NULL
    if (spillover) {
      cl     <- NULL
      on.exit({
        registerDoSEQ()
        try(stopCluster(cl), silent = TRUE)
      }, add = TRUE)
      
      cl     <- makeCluster(nthread)
      registerDoParallel(cl)
      registerDoRNG(seed)
      
      outbt  <- foreach(k         = 1:nboot, 
                        .export   = c("fbt", "fAsyobjbt", "fAsyparmsbt"), #comment out
                        .packages = c("AsyPeer") 
      ) %dorng% {
        sdk  <- as.integer(runif(1, 0, 1e9))
        ## Bootstrap sample
        bt   <- fbt(Zeta0 = opt$moment, Z = Z, y = y, V = V, lIso = lIso,
                    lnIso = lnIso, spillover = spillover, seed = sdk)
        ## Optimization
        opts <- optimize(f = fAsyobjbt, lower = -0.5, upper = 100, tol = tol.optim,
                         Z = bt$Z, Zty = bt$Zty, V = bt$V, W = W, n_nIso = bt$n_nIso)
        ## Parameters and moment
        fAsyparmsbt(betal = opts$minimum, Z = bt$Z, Zty = bt$Zty, V = bt$V, 
                    W = W, n_nIso = bt$n_nIso, asymmetry)
      }
    } else {
      cl     <- NULL
      on.exit({
        registerDoSEQ()
        try(stopCluster(cl), silent = TRUE)
      }, add = TRUE)
      
      cl     <- makeCluster(nthread)
      registerDoParallel(cl)
      registerDoRNG(seed)
      
      outbt  <- foreach(k         = 1:nboot, 
                        .export   = c("fbt", "fAsyobjbt", "fAsyparmsbt"), #comment out
                        .packages = c("AsyPeer") 
      ) %dorng% {
        sdk  <- as.integer(runif(1, 0, 1e9))
        ## Bootstrap sample
        bt   <- f_nospillbt(Zeta0 = opt$moment, Z = Z, y = y, 
                            Gy = endo[,paste0(yname, "_bar")], V = V, lIso = lIso, 
                            lnIso = lnIso, spillover = spillover, seed = sdk)
        ## Optimization
        opts <- optimize(f = fAsyobj_nospillbt, lower = -0.5, upper = 100, tol = tol.optim,
                         Z = bt$Z, Zty = bt$Zty, ZtGy = bt$ZtGy, V = bt$V, W = W, 
                         n_nIso = bt$n_nIso)
        ## Parameters and moment
        fAsyparms_nospillbt(betal = opts$minimum, Z = bt$Z, Zty = bt$Zty,
                            ZtGy = bt$ZtGy, V = bt$V, W = W, n_nIso = bt$n_nIso, 
                            asymmetry = asymmetry)
      }
    }
    
    Cov     <- fAsyparmsVar_bt(outbt = outbt, theta0 = opt$theta, Zeta0 = opt$moment,
                               asymmetry = asymmetry, spillover = spillover)
    
  } else {
    
    fAsyC   <- fAsyparms_nospill
    if (spillover) {
      fAsyC <- fAsyparms
    }
    Cov     <- fAsyC(theta = opt$theta, V = V, sVphi = opt$sVphi, eta = opt$eta, 
                     Z = Z, y = y, endo = endo, X = X, W = W, Iso = Iso, 
                     nIso = nIso, cumsn = cumsn, nc_gamma = ncgamma, dfiso = dfiso,
                     dfniso = dfniso, HAC = HACn, S = S)
    
  }
  
  
  ### unscale residuals
  opt$eta[nIso + 1] = opt$eta[nIso + 1] * (1 + opt$theta[1])
  
  ## Shape the output
  gmm     <- list(Estimate = Cov$estimate,
                  cov      = Cov$cov,
                  sigma    = c(overall = Cov$serr, isolates = Cov$serriso, nonisolates = Cov$serrniso),
                  Sargan   = list(stat   = ifelse(Cov$Jdf > 0, Cov$Jstat, NA),
                                  df     = Cov$Jdf,
                                  pvalue = ifelse(Cov$Jdf > 0, 1 - pchisq(Cov$Jstat, Cov$Jdf), NA)))
  ## Test for asymmetry
  if (asymmetry) {
    gmm   <- c(gmm, list("diffbeta" = c("Estimate" = Cov$TestAsym[1],
                                        "SE"       = Cov$TestAsym[2],
                                        "p-value"  = Cov$TestAsym[3])))
  }
  gmm     <- c(gmm, list(unscale.resid = opt$eta, objective = opt$objective / S^2))
  
  gname   <- paste0("gamma:", xname)
  if (length(ncgamma) > 0) {
    gname <- c(gname, paste0("isogamma:", xname[ncgamma + 1]))
  }
  if(spillover){
    if(asymmetry){
      names(gmm$Estimate) <- colnames(gmm$cov) <- rownames(gmm$cov) <- 
        c("betal", "betah", "delta", gname)
    } else {
      names(gmm$Estimate) <- colnames(gmm$cov) <- rownames(gmm$cov) <- 
        c("beta", "delta", gname)
    }
  } else {
    if(asymmetry){
      names(gmm$Estimate) <- colnames(gmm$cov) <- rownames(gmm$cov) <- 
        c("betal", "betah", gname)
    } else {
      names(gmm$Estimate) <- colnames(gmm$cov) <- rownames(gmm$cov) <- 
        c("beta", gname)
    }
  }
  
  out     <- list(model.info  = c(list(n = n, nisolates = n_iso, ngroup = S, nvec = nvec, formula = formula, 
                                       excluded.instruments = excluded.instruments, xname = xname, yname = yname, 
                                       zname = zname, spillover = spillover, asymmetry = asymmetry, 
                                       fixed.effects = fixed.effects, weight = weight, HAC = HAC, tol = tol, 
                                       dfiso = dfiso, dfniso = dfniso, common.gamma = xname[cgamma + 1],
                                       ncommon.gamma = xname[ncgamma + 1]), detInst),
                  gmm         = gmm,
                  data        = list(dependent = y, exogenous = X,
                                     endogenous.variables = endo, instruments = Z, 
                                     degree = dg, isolates = lapply(lIso, \(x) x + 1),
                                     non.isolates = lapply(lnIso, \(x) x + 1)))
  class(out) <- "asypeer.estim"
  out
}

#' @title Summary and Print Methods for the Asymmetric Peer Effects Model
#' @param object An object of class \code{\link{asypeer.estim}} as returned by the function \link{asypeer.estim}.
#' @param diagnostics,diagnostic A logical value indicating whether diagnostic tests for the IV GMM should be performed.
#'   These include an F-test of the first-stage regression for weak instruments, a Wu-Hausman test
#'   for endogeneity, and a Hansen's J-test for overidentifying restrictions (the latter only when
#'   the number of instruments exceeds the number of regressors).
#' @param KP A logical value indicating whether a Kleibergen-Paap Wald test should be performed in addition to the standard F test 
#'   of the first-stage regression for weak instruments. should be performed instead of the standard F test.
#' @param SW Logical value indicating whether the Sanderson–Windmeijer conditional F-statistic is computed instead of the classical first-stage F-statistic.
#' @param nthread A strictly positive integer specifying the number of threads used in
#'   computationally intensive steps of the estimation procedure.
#' @param x An object of class \code{\link{summary.asypeer.estim}} or \code{\link{asypeer.estim}} as returned by the function \link{summary.asypeer.estim} or \link{asypeer.estim}, respectively.
#' @param ... Further arguments passed to or from other methods.
#'
#' @description
#' Summary and print methods for objects of class \code{\link{asypeer.estim}}.
#'
#' @return A list containing:
#'   \item{model.info}{A list containing information about the model, such as the number of subnets,
#'     number of observations, and other key details.}
#'   \item{coefficients}{A summary of coefficient estimates, standard errors, and p-values.}
#'   \item{diagnostics}{A summary of the diagnostic tests for the instrumental-variable regression,
#'     if requested.}
#'   \item{gmm}{A list of GMM estimation results, including parameter estimates, the covariance matrix,
#'     and related statistics.}
#'
#' @export
#' @method summary asypeer.estim
summary.asypeer.estim <- function(object, 
                                  diagnostic  = FALSE, 
                                  diagnostics = FALSE,
                                  SW          = FALSE,
                                  KP          = diagnostics || diagnostic,  
                                  nthread     = 1L,
                                  ...) {
  stopifnot(inherits(object, "asypeer.estim"))
  diagn  <- NULL
  if (diagnostic || diagnostics) {
    tp   <- fnthreads(nthread = nthread)
    if ((tp == 1) & (nthread != 1)) {
      warning("OpenMP is not available. Sequential processing is used.")
      nthread <- tp
    }
    diagn <- fdiagnostic(object, KP, SW, nthread)
  }
  yname   <- object$model.info$yname
  xnames  <- object$model.info$xnames
  
  est     <- object$gmm$Estimate
  covt    <- object$gmm$cov
  
  coef    <- fcoef(Estimate = est, cov = covt)
  out     <- c(object["model.info"], 
               list(coefficients = coef, 
                    diagnostics  = diagn),
               object["gmm"], list(...))
  class(out) <- "summary.asypeer.estim"
  out
}

#' @rdname summary.asypeer.estim
#' @export
print.summary.asypeer.estim <- function(x, ...) {
  esti <- ifelse(x$model.info$weight == "identity", "GMM (Weight: Identity Matrix)", 
                 ifelse(x$model.info$weight == "optimal", "GMM (Weight: Optimal)",
                        ifelse(x$model.info$weight == "IV", "GMM (Weight: IV)" )))
  hete <- x$model.info$HAC
  hete <- ifelse(hete %in% c("iid", "group-iid"), hete,
                 ifelse(hete == "hetero", "Individual", 
                        ifelse(hete == "cluster", "Cluster", "Cluster (Bootstrap)")))
  sig_overall  <- x$gmm$sigma["overall"]
  sig_iso      <- x$gmm$sigma["isolates"]
  sig_niso     <- x$gmm$sigma["nonisolates"]
  FE           <- x$model.info$fixed.effects
  
  inst     <- ""
  if (is.null(x$model.info$excluded.instruments)) {
    if (x$model.info$full.pred) {
      inst <- ifelse(x$model.info$asymmetry, "predictions of y_bar and y_check", 
                     "predictions of y_bar")
    } else {
      inst <- paste("(G^p)X with max(p) =", max(x$model.info$power),
                    ifelse(x$model.info$asymmetry, "and predictions of y_check", ""))
    }
  }
  
  cat("Formula: ", deparse(x$model.info$formula),
      "\nExcluded instruments: ", ifelse(!is.null(x$model.info$excluded.instruments), 
                                         deparse(x$model.info$excluded.instruments),
                                         inst),
      "\n\n# Subnetworks: ", x$model.info$ngroup,
      "\n# Isolates: ", x$model.info$nisolates,
      "\n# Non-isolates: ", x$model.info$n - x$model.info$nisolates,
      "\n\nEstimator: ", esti,
      "\nFixed effects: ", ifelse(FE, "Yes", "No"), "\n", sep = "")
  
  coef       <- x$coefficients
  coef[,1:2] <- round(coef[,1:2], 7)
  coef[,3]   <- round(coef[,3], 5)
  cat("\nCoefficients:\n")
  fprintcoeft(coef)
  
  if (!is.null(x$diagnostics)) {
    coef       <- x$diagnostics
    coef[,3]   <- round(coef[,3], 5)
    cat("\nDiagnostic tests:\n")
    fprintcoeft(coef) 
  }
  cat("---\nSignif. codes:  0 \u2018***\u2019 0.001 \u2018**\u2019 0.01 \u2018*\u2019 0.05 \u2018.\u2019 0.1 \u2018 \u2019 1\n")
  
  if (x$model.info$asymmetry) {
    cat("\nTesting for Symmetry\n")
    cat("betah - betal:", unname(x$gmm$diffbeta[1]))
    cat(" (p-value: ", ifelse(x$gmm$diffbeta[3] < 2e-16, "<2e-16", format(unname(x$gmm$diffbeta[3]), digit = 4)), ")\n", sep = "")
  }
  
  cat("\nHAC: ", hete, "\n", sep = "")
  if(hete %in% c("group-iid")){
    cat(", sigma (isolates): ", format(sig_iso, digits = 5), ", (non-isolates): ", format(sig_niso, digits = 5), "\n", sep = "")
  } else if (hete == "iid") {
    cat(", sigma: ", format(sig_overall, digits = 5), "\n", sep = "")
  }
  
  ## range
  delta   <- 0
  if (x$model.info$spillover) {
    delta <- x$gmm$Estimate["delta"]
  }
  minbeta <- ifelse(x$model.info$asymmetry, min(x$gmm$Estimate[c("betal", "betah")]), x$gmm$Estimate["beta"])
  maxbeta <- ifelse(x$model.info$asymmetry, max(x$gmm$Estimate[c("betal", "betah")]), x$gmm$Estimate["beta"])
  if (minbeta > -1) {
    if(x$model.info$asymmetry){ 
      boundl <- unname((delta + minbeta) / (1 + minbeta))
      boundh <- unname((delta + maxbeta) / (1 + maxbeta))
      if ((abs(boundl) < 1) && (abs(boundh) < 1)) {
        cat("Total Peer Effects Range:", " [", deparse(round(boundl,4)),", ", deparse(round(boundh,4)),"]\n", sep = "")
      } else{
        warning("Total Peer effects are outside the [-1, 1] interval, there might be multiple equilibria.\n")
      }
    } else {
      bound  <- unname((delta + minbeta) / (1 + minbeta))
      if (abs(bound) < 1) {
        cat("Total Peer Effects: ",deparse(round(bound,4)), "\n", sep = "")
      } else{
        warning("Total Peer effects are outside the [-1, 1] interval, there might be multiple equilibria.\n")
      }
    }
  } else{
    warning("Conformity parameter lower than -0.5; total Peer effects are outside the [-1, 1] interval.\n")
  }
  
  class(x) <- "print.summary.asypeer.estim"
  invisible(x)
}

#' @rdname summary.asypeer.estim
#' @export
print.asypeer.estim <- function(x, ...) {
  print(summary(x))
}


ifnullset <- function(x, value) {
  if (is.null(x)) {
    return(value)
  }
  x
}

